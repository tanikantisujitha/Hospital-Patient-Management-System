HOSPITAL PATIENT MANAGEMENT SYSTEM — WEBSITE

How to run:
1. Extract Hospital_Patient_Management_Website.zip.
2. Open the extracted folder.
3. Double-click index.html. It opens in your web browser.
4. No installation or server is required.

Features:
- Dashboard with total patients, emergency cases, ICU patients and general ward count.
- Add, view, search, update and delete patient records.
- Emergency cases appear first in the priority list.
- Transfer patients between General Ward and ICU.
- Records are saved in the browser using localStorage.

Important:
This is a front-end educational demonstration only. Do not enter real patient or confidential medical information. Data is stored only in the browser used to open the website. Clearing browser data may remove the records.
