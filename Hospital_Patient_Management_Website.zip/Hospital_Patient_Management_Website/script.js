const KEY = "carepoint_patients_v1";
let patients = JSON.parse(localStorage.getItem(KEY) || "[]");
const $ = id => document.getElementById(id);
const initials = name => name.split(/\s+/).map(x=>x[0]).join("").slice(0,2).toUpperCase();
const save = () => localStorage.setItem(KEY, JSON.stringify(patients));
const escapeHTML = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2300)}
function go(page){document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));$(page+"-page").classList.add("active");document.querySelectorAll(".nav-link").forEach(a=>a.classList.toggle("active",a.dataset.page===page));$("page-title").textContent=({dashboard:"Dashboard",patients:"Patient records","add-patient":"Add Patient",icu:"ICU Transfers"})[page];if(page==="add-patient" && !$("edit-id").value) resetForm();render()}
document.querySelectorAll(".nav-link").forEach(a=>a.addEventListener("click",e=>{e.preventDefault();go(a.dataset.page)}));
document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.go)));
$("today").textContent=new Intl.DateTimeFormat("en-IN",{weekday:"short",day:"numeric",month:"short",year:"numeric"}).format(new Date());

function sorted(list){return [...list].sort((a,b)=>(b.priority==="Emergency")-(a.priority==="Emergency") || b.created-a.created)}
function patientCell(p){return `<div class="patient-cell"><span class="patient-avatar">${escapeHTML(initials(p.name))}</span><span><strong>${escapeHTML(p.name)}</strong><small>${escapeHTML(p.phone)}</small></span></div>`}
function render(){
  const emergency=patients.filter(p=>p.priority==="Emergency"), icu=patients.filter(p=>p.ward==="ICU");
  $("total-count").textContent=patients.length;$("emergency-count").textContent=emergency.length;$("icu-count").textContent=icu.length;$("ward-count").textContent=patients.length-icu.length;
  $("recent-body").innerHTML=sorted(patients).slice(0,5).map(p=>`<tr><td>${patientCell(p)}</td><td>${escapeHTML(p.id)}</td><td>${escapeHTML(p.illness)}</td><td><span class="tag ward-tag">${escapeHTML(p.ward)}</span></td></tr>`).join("") || `<tr><td colspan="4" class="empty-state">No patient records yet.</td></tr>`;
  $("priority-list").innerHTML=sorted(emergency).slice(0,5).map(p=>`<div class="priority-item"><div><strong>${escapeHTML(p.name)}</strong><small>${escapeHTML(p.illness)} · ${escapeHTML(p.id)}</small></div><span class="tag red-tag">Emergency</span></div>`).join("") || `<div class="empty-state">No emergency cases recorded.</div>`;
  renderPatients();renderTransfers();
}
function renderPatients(){
  const q=$("search-input").value.toLowerCase(), ward=$("filter-ward").value, priority=$("filter-priority").value;
  const list=sorted(patients).filter(p=>([p.name,p.id,p.illness].join(" ").toLowerCase().includes(q))&&(ward==="all"||p.ward===ward)&&(priority==="all"||p.priority===priority));
  $("patients-body").innerHTML=list.map(p=>`<tr><td>${patientCell(p)}</td><td>${escapeHTML(p.id)}</td><td>${p.age} / ${escapeHTML(p.gender)}</td><td>${escapeHTML(p.illness)}</td><td><span class="tag ${p.priority==="Emergency"?"red-tag":"normal-tag"}">${escapeHTML(p.priority)}</span></td><td><span class="tag ward-tag">${escapeHTML(p.ward)}</span></td><td><button class="action-btn" data-edit="${escapeHTML(p.id)}">Edit</button><button class="action-btn danger" data-delete="${escapeHTML(p.id)}">Delete</button></td></tr>`).join("");
  $("empty-state").hidden=list.length>0;
  document.querySelectorAll("[data-edit]").forEach(b=>b.onclick=()=>editPatient(b.dataset.edit));
  document.querySelectorAll("[data-delete]").forEach(b=>b.onclick=()=>deletePatient(b.dataset.delete));
}
function renderTransfers(){
  const general=sorted(patients.filter(p=>p.ward!=="ICU"));
  $("transfer-body").innerHTML=general.map(p=>`<tr><td>${patientCell(p)}</td><td>${escapeHTML(p.id)}</td><td>${escapeHTML(p.illness)}</td><td><span class="tag ${p.priority==="Emergency"?"red-tag":"normal-tag"}">${escapeHTML(p.priority)}</span></td><td><button class="action-btn" data-transfer="${escapeHTML(p.id)}">Transfer to ICU</button></td></tr>`).join("");
  $("icu-empty").hidden=general.length>0;
  $("icu-current-list").innerHTML=patients.filter(p=>p.ward==="ICU").map(p=>`<div class="icu-card"><strong>${escapeHTML(p.name)} · ${escapeHTML(p.id)}</strong><small>${escapeHTML(p.illness)} · ${escapeHTML(p.priority)} priority</small><button class="action-btn" data-return="${escapeHTML(p.id)}">Return to General Ward</button></div>`).join("") || `<div class="empty-state">No patients currently assigned to ICU.</div>`;
  document.querySelectorAll("[data-transfer]").forEach(b=>b.onclick=()=>transfer(b.dataset.transfer,"ICU"));
  document.querySelectorAll("[data-return]").forEach(b=>b.onclick=()=>transfer(b.dataset.return,"General Ward"));
}
function resetForm(){$("patient-form").reset();$("edit-id").value="";$("form-heading").textContent="Add new patient";$("save-button").textContent="Save patient"}
function editPatient(id){const p=patients.find(x=>x.id===id);if(!p)return;go("add-patient");$("edit-id").value=p.id;$("patient-id").value=p.id;$("patient-id").disabled=true;$("patient-name").value=p.name;$("patient-age").value=p.age;$("patient-gender").value=p.gender;$("patient-illness").value=p.illness;$("patient-phone").value=p.phone;$("patient-ward").value=p.ward;$("patient-priority").value=p.priority;$("form-heading").textContent="Update patient";$("save-button").textContent="Update patient"}
function deletePatient(id){if(!confirm("Delete patient "+id+"?"))return;patients=patients.filter(p=>p.id!==id);save();render();toast("Patient record deleted")}
function transfer(id,ward){const p=patients.find(x=>x.id===id);if(!p)return;p.ward=ward;save();render();toast(p.name+" moved to "+ward)}
$("patient-form").addEventListener("submit",e=>{e.preventDefault();const edit=$("edit-id").value;const p={id:$("patient-id").value.trim(),name:$("patient-name").value.trim(),age:Number($("patient-age").value),gender:$("patient-gender").value,illness:$("patient-illness").value.trim(),phone:$("patient-phone").value.trim(),ward:$("patient-ward").value,priority:$("patient-priority").value,created:Date.now()};
  if(!edit && patients.some(x=>x.id.toLowerCase()===p.id.toLowerCase())){toast("Patient ID already exists");return}
  if(edit){const i=patients.findIndex(x=>x.id===edit);if(i>=0)patients[i]={...patients[i],...p,id:edit};$("patient-id").disabled=false;toast("Patient details updated")}else{patients.push(p);toast("Patient added successfully")}
  save();resetForm();$("patient-id").disabled=false;go("patients");
});
$("cancel-form").onclick=()=>{resetForm();$("patient-id").disabled=false;go("patients")};
["search-input","filter-ward","filter-priority"].forEach(id=>$(id).addEventListener("input",renderPatients));
render();
